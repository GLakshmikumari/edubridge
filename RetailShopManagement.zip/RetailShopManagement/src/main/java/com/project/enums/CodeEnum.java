package com.project.enums;

public interface CodeEnum {
	Integer getCode();
}
