package com.project.service;

import com.project.entity.ProductInOrder;
import com.project.entity.User;

public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
