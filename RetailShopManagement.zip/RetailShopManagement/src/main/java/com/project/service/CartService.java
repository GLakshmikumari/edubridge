package com.project.service;



import java.util.Collection;

import com.project.entity.Cart;
import com.project.entity.ProductInOrder;
import com.project.entity.User;


public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
