package com.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryAppProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
